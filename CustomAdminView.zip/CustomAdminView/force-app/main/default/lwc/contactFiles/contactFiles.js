import { LightningElement } from 'lwc';

export default class ContactFiles extends LightningElement {}