import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

export default class SecureDownloadButton extends NavigationMixin(LightningElement) {
    @api contentDocumentId; // 18-char Id of ContentDocument
    @api contentVersionId; // 18-char Id of ContentVersion
    @api recordId; // auto-wired when placed on a record page
    @api label = 'Download';
    @api title = 'Download File';
    @api variant = 'brand';
    @api disabled = false;

    handleClick() {
        const url = this.buildDownloadUrl();
        if (!url) {
            // No valid id provided; do nothing
            return;
        }
        // Navigate to file download route; Apex handler enforces restrictions
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url
            }
        });
    }

    buildDownloadUrl() {
        // Prefer ContentVersion for direct download; fall back to latest by ContentDocument
        const versionId = this.contentVersionId || (this.recordId && this.recordId.startsWith('068') ? this.recordId : null);
        if (versionId) {
            return `/sfc/servlet.shepherd/version/download/${versionId}`;
        }
        const documentId = this.contentDocumentId || (this.recordId && this.recordId.startsWith('069') ? this.recordId : null);
        if (documentId) {
            return `/sfc/servlet.shepherd/document/download/${documentId}`;
        }
        return null;
    }

    get isDisabled() {
        return this.disabled || !this.buildDownloadUrl();
    }
}

